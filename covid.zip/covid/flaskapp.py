from flask import Flask, request, render_template
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from nltk.corpus import stopwords
import tensorflow as tf
import pickle
from keras.preprocessing.sequence import pad_sequences


nltk.download('stopwords')

set(stopwords.words('english'))
app = Flask(__name__)

@app.route('/')
def my_form():
    return render_template('form.html')

@app.route('/', methods=['POST'])
def my_form_post():
    #stop_words = stopwords.words('english')
    text1 = request.form['text1'].lower()

    with open('tokenizercovid.pkl', 'rb') as input:
         tokenizer = pickle.load(input)
         #print(token1.token)
         tokenizer.fit_on_texts(text1)

    list_tokenized_train = tokenizer.texts_to_sequences(text1)
    maxlen = 130
    X_t = pad_sequences(list_tokenized_train, maxlen=maxlen)
    #processed_doc1 = ' '.join([word for word in text1.split() if word not in stop_words])
    embed_size = 129
    #sa = SentimentIntensityAnalyzer()
    #dd = sa.polarity_scores(text=processed_doc1)
    #compound = round((1 + dd['compound'])/2, 2)
    new_model = tf.keras.models.load_model('covidmode.h5')
    y_pred = new_model.predict(X_t)
    y_new = new_model.predict_classes(X_t)
    #print(y_new)

    return render_template('form.html', final=y_new, text1=text1)

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5002, threaded=True)
